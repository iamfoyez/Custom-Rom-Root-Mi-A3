#!/sbin/sh 
find /vendor/etc -name "fstab.*" -exec sed -i 's/forceencrypt/encryptable/g' {} +
find /vendor/etc -name "fstab.*" -exec sed -i 's/forcefdeorfbe/encryptable/g' {} +
find /vendor/etc -name "fstab.*" -exec sed -i 's/fileencryption/encryptable/g' {} +
